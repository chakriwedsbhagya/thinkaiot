<!doctype html>
<html class="no-js" lang="en">
  <head>
    <title>Product Overview | mTantu</title>
    <?php include('top.php'); ?>
    <style type="text/css">
      .overview-text li {
        display: inline-block;
        width: 50%;
        margin: 0 -2px;
        vertical-align: top;
      }
      .overview-text ul li a {
        padding: 6px 20px 6px 40px;
      }
    </style>
  </head>
  <body>
    <?php include('header.php'); ?>











    <div class="page-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="breadcrumb text-center">
              <div class="bread-content">
                <div class="section-headline white-headline text-center">
                  <h2>Product Overview</h2>
                </div>
                <ul>
                  <li class="home-bread">Home</li>
                  <li>Product Overview</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>










































    <div class="about-area about-area-3 bg-color area-padding">
      <div class="container">
        <div class="row">

          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="overview-text" style="margin: 0;">
              <h2 class="text-center">Why mTantu?</h2>
              <ul>
                <li><a href="#">Complement your access points with end user experience data and service level quality assurance</a></li>
                <li><a href="#">Get system-wide WLAN visibility and quickly determine if issues are wired, wireless or client device related</a></li>
                <li><a href="#">24×7 Wi-Fi network benchmarking and service level compliance alerting</a></li>
                <li><a href="#">Find and fix Wi-Fi issues from anywhere</a></li>
              </ul>
            </div>
          </div>

        </div>
      </div>
    </div>


































    <div class="area-padding-2">
      <div class="container">

        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>mTantu HW SPEC</h2>
            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-md-12 col-sm-12 col-xs-12 wrrpr_0625280820">




            <div class="dv_0625280820">
              <img src="img/img4.png" class="img_0625280820">
              <ul class="lst_0625280820 lst1_0625280820">
                <li><span>1</span> Multiple power options (PoE, Micro USB)</li>
                <li><span>2</span> 10 Hours battery backup</li>
                <li><span>3</span> WIFI 802.11ac (Wave2) 3T3R MIMO antenna / 802.11ax(WIFI6) radio chipset compatible HAT</li>
                <li><span>4</span> BLE 5.0 MESH support</li>
                <li><span>5</span> 4G LTE  / LoRaWAN configurable backhaul  </li>
                <li><span>6</span> Inbuilt GPS(Enables outdoor MESH-Sensor deployments easy, Fast-NTP Sync up; seamless automatic on-boarding upon power-on)</li>
              </ul>
              <ul class="lst_0625280820 lst2_0625280820">
                <li><span>7</span> FLASH Memory(32GB,64GB,512GB,2TB) and 1GB~8GB RAM</li>
                <li><span>8</span> Integrated camera (variable lens Options ranging from 2.0 mm to 5.7 mm supporting heights from 2.4 m to 20 m (8 ft up to 65 ft) )</li>
                <li><span>9</span> USB 3.0 bridge enables Plug ‘n’ Play / Hot plug support (Enterprise Sensor MESH-deployment sensor can be turned on to carter AI @ EDGE [Not relying on the connection with the cloud] WAN link not required)</li>
                <li><span>10</span> Secure data-logging retention 60+ days ( software configurable)</li>
              </ul>
            </div>






          </div>

        </div>

      </div>
    </div>





























































    <div class="area-padding bg-color dv_0310270820">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>Synthetic Test Suites</h2>
            </div>
          </div>
        </div>
        <div class="row">


          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>WebAuth</h3>
              <ul style="min-height: 220px">
                <li>Onboarding events test(Wired/Wireless)</li>
                <li>Splash page test</li>
                <li>Internal WebAuth test</li>
                <li>External Webauth test</li>
                <li>Virtual IP test</li>
                <li>Passthrough + AAA test </li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>Traceroute</h3>
              <ul style="min-height: 220px">
                <li>Number of hops</li>
                <li>TCP/UDP/ICMP protocol</li>
                <li>Path-MTU</li>
                <li>Hop-by-Hop RTT</li>
                <li>DSCP marking</li>
                <li>Destination TCP/IP port</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>Security Guard</h3>
              <ul style="min-height: 220px">
                <li>Against Wi-Fi Pineapple attacks </li>
                <li>MIM attacks , BW-Stealing , Continuous request redirections</li>
                <li>Deep packet inspection into DHCP DORA and EAP timing metrics , WI-Fi L1,L2 events</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>iPerf</h3>
              <ul style="min-height: 220px">
                <li>TCP/UDP Bandwidth</li>
                <li>Custom TCP/IP ports</li>
                <li>Multicast</li>
                <li>QoS</li>
                <li>Jitter</li>
                <li>Packet Loss</li>
                <li>DSCP marking</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>IPSLA</h3>
              <ul style="min-height: 160px">
                <li>UDP Probes</li>
                <li>UDP-Echo,UDP-Jitter v1,v2</li>
                <li>RTT , NTP-One_Way Latency</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>Speedtest</h3>
              <ul style="min-height: 160px">
                <li>Download speed</li>
                <li>Upload speed</li>
                <li>Custom server</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>TCP-based PING test</h3>
              <ul style="min-height: 160px">
                <li>Packet Loss</li>
                <li>Round-Trip Time</li>
                <li>DSCP marking</li>
                <li>MTU and DF setting</li>
                <li>Custom Port</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>VoIP Testing</h3>
              <ul style="min-height: 160px">
                <li>Mean Opinion Score</li>
                <li>Packet Loss</li>
                <li>Jitter G711, G729, G723, G726, G728</li>  
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>PING</h3>
              <ul style="min-height: 210px">
                <li>End-to-End connectivity</li>
                <li>Packet Loss</li>
                <li>Round-Trip Time</li>
                <li>DSCP marking</li>
                <li>MTU and DF setting</li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>RADIUS</h3>
              <ul style="min-height: 210px">
                <li>CHAP , PAP onboarding</li>
                <li>EAP-TLS , KEY-Ex,Pass-key</li>
                <li>Loopback test </li>
                <li>Wired/Wireless Events onboarding test  </li>
                <li>RADIUS failure events streaming test </li>
              </ul>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1033270820">
            <div class="dv_1033270820">
              <h3>PAYLOADS</h3>
              <ul style="min-height: 210px">
                <li>Payload decoding test</li>
                <li>Protocol sequencing test</li>
                <li>MAC-IP mapping test</li>
                <li>BW throttling test </li>
                <li>Traffic shaping test</li>
                <li>QoS/QoE test </li>
              </ul>
            </div>
          </div>


        </div>
      </div>
    </div>






















































    <?php include('footer.php'); ?>
  </body>
</html>