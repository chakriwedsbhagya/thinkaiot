<!doctype html>
<html class="no-js" lang="en">
  <head>
    <title>About Mtantu | mTantu</title>
    <?php include('top.php'); ?>
  </head>
  <body>
    <?php include('header.php'); ?>











    <div class="page-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="breadcrumb text-center">
              <div class="bread-content">
                <div class="section-headline white-headline text-center">
                  <h2>About Mtantu</h2>
                </div>
                <ul>
                  <li class="home-bread">Home</li>
                  <li>About Mtantu</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>








    <div class="team-area bg-color-2 area-padding-2">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>mTantu - Milestones</h2>
              <!-- <p>We help agencies to define their new business objectives and then create the road map</p> -->
            </div>
          </div>
        </div>
        <div class="row">














          <div class="col-md-12 col-sm-12 col-xs-12 timeline_wrrpr">
            
            <ul class="timeline">












































              <!-- <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">June 2020</span>
                  </div>
                  <div class="desc">Edge#AI Early warning system</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2020</span>
                  </div>
                  <div class="desc">Predictive analytics</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Nov 2019</span>
                  </div>
                  <div class="desc">Edge Analytics</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Oct 2019</span>
                  </div>
                  <div class="desc">Headless WebRTC, VoIP MOS, MTTR feature, Mid-level Analytics Drop</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">June 2019</span>
                  </div>
                  <div class="desc">Real User Monitoring, AVC, Traffic shaping</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">May 2019</span>
                  </div>
                  <div class="desc">US Patent Filling</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Mar 2019</span>
                  </div>
                  <div class="desc">Wired/ Wireless backhal (Wifi/ LTE)</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2019</span>
                  </div>
                  <div class="desc">Hybrid Cloud Deployment models Acceptance Test</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Dec 2018</span>
                  </div>
                  <div class="desc">Closed loop automation</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Nov 2018</span>
                  </div>
                  <div class="desc">Single plane glass management initial drop</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">July 2018</span>
                  </div>
                  <div class="desc">Wireless Services Assurance Agent and its validation over opensource-HW platforms</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Mar 2018</span>
                  </div>
                  <div class="desc">Onshore/ Offshor R&D team mobilization</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Feb 2018</span>
                  </div>
                  <div class="desc">Enterprise Wifi Analytics Sensor features and design finalzati</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2018</span>
                  </div>
                  <div class="desc">MCPS Associati</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">MID 2017</span>
                  </div>
                  <div class="desc">Initial Idea was born</div>
                </div>
              </li> -->
































              







              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Jun 2017</span>
                  </div>
                  <div class="desc">Initial Idea was born</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2018</span>
                  </div>
                  <div class="desc">MCPS Associati</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Feb 2018</span>
                  </div>
                  <div class="desc">Enterprise Wifi Analytics Sensor features and design finalzati</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Mar 2018</span>
                  </div>
                  <div class="desc">Onshore/ Offshor R&D team mobilization</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">July 2018</span>
                  </div>
                  <div class="desc">Wireless Services Assurance Agent and its validation over opensource-HW platforms</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Nov 2018</span>
                  </div>
                  <div class="desc">Single plane glass management initial drop</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Dec 2018</span>
                  </div>
                  <div class="desc">Closed loop automation</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2019</span>
                  </div>
                  <div class="desc">Hybrid Cloud Deployment models Acceptance Test</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Mar 2019</span>
                  </div>
                  <div class="desc">Wired/ Wireless backhal (Wifi/ LTE)</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">May 2019</span>
                  </div>
                  <div class="desc">US Patent Filling</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">June 2019</span>
                  </div>
                  <div class="desc">Real User Monitoring, AVC, Traffic shaping</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Oct 2019</span>
                  </div>
                  <div class="desc">Headless WebRTC, VoIP MOS, MTTR feature, Mid-level Analytics Drop</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">Nov 2019</span>
                  </div>
                  <div class="desc">Edge Analytics</div>
                </div>
              </li>
              
              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Jan 2020</span>
                  </div>
                  <div class="desc">Predictive analytics</div>
                </div>
              </li>

              <li>
                <div class="direction-r">
                  <div class="flag-wrapper">
                    <span class="flag">June 2020</span>
                  </div>
                  <div class="desc">Edge#AI Early warning system</div>
                </div>
              </li>

              <li>
                <div class="direction-l">
                  <div class="flag-wrapper">
                    <span class="flag">Today</span>
                  </div>
                  <div class="desc" style="min-height: 150px">Active/ Passive WIFI analytics sensor, Soft Sensor (Android, ios, Windows, Linux), Edge-analytics Fusion engine, Enterprise Software as a Service (SaaS) application</div>
                  <img class="timl_img" src="img/img7.png" style="right: -250px;">
                </div>
              </li>








              
            </ul>

          </div>















        </div>
      </div>
    </div>






    <?php include('footer.php'); ?>
  </body>
</html>