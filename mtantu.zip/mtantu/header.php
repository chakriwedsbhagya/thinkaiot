
<header class="header-one">
  <!-- Start top bar -->
  <div class="topbar-area fix hidden-xs">
    <div class="container">
      <div class="row">
        <div class=" col-md-9 col-sm-9">
          <div class="topbar-left">
            <ul>
              <!-- <li><a href="mailto:info@mtantu.com"><i class="fa fa-envelope"></i> info@mtantu.com</a></li> -->
              <!-- <li><a href="tel:2145754500"><i class="fa fa-phone-square"></i> (214)5754500</a></li> -->
              <li><p>NEWS governed Wireless Network Monitoring</p></li>
            </ul>
          </div>
        </div>
        <div class="col-md-3 col-sm-3">
          <div class="top-social">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End top bar -->
  <!-- header-area start -->
  <div id="sticker" class="header-area hidden-xs">
    <div class="container">
      <div class="row">
        <!-- logo start -->
        <div class="col-md-2 col-sm-3">
          <div class="logo">
            <a class="navbar-brand" href="index.php">
              <img src="img/logo/logo.png" alt="">
            </a>
          </div>
        </div>
        <div class="col-md-10 col-sm-9">
          <div class="header-right-link">
            <!-- <div class="search-inner">
              <form action="#">
                <div class="search-option">
                  <input type="text" placeholder="Search...">
                  <button class="button" type="submit"><i class="fa fa-search"></i></button>
                </div>
                <a class="main-search" href="#"><i class="fa fa-search"></i></a>
              </form>
            </div> -->
            <a class="s-menu anti-btn" href="#" data-toggle="modal" data-target="#get_a_quote_popup">Get a Quote</a>
          </div>
          <nav class="navbar navbar-default">
            <div class="collapse navbar-collapse" id="navbar-example">
              <div class="main-menu">
                <ul class="nav navbar-nav navbar-right">

                  <li><a href="index.php">Home</a></li>
                  <li><a href="product_overview.php">Product Overview</a></li>
                  <li><a href="about_mtantu.php">About mTantu</a></li>
                  <li><a href="team.php">Team</a></li>
                  <li><a href="support.php">Support</a></li>
                  <li><a href="#">Patent</a></li>

                  <!-- <li>
                    <a class="pages" href="#">Blog</a>
                    <ul class="sub-menu">
                      <li><a href="#">Blog grid</a></li>
                      <li><a href="#">Blog List</a></li>
                      <li><a href="#">Blog Details</a></li>
                    </ul>
                  </li> -->

                </ul>
              </div>
            </div>
          </nav>
          <!-- mainmenu end -->
        </div>
      </div>
    </div>
  </div>
  <!-- header-area end -->
  <!-- mobile-menu-area start -->
  <!-- <div class="mobile-menu-area hidden-lg hidden-md hidden-sm">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mobile-menu">
            <div class="logo">
              <a href="#"><img src="img/logo/logo.png" alt="" /></a>
            </div>
            <nav id="dropdown">
              <ul>
                <li>
                  <a class="pages" href="#">Home</a>
                  <ul class="sub-menu">
                    <li><a href="#">Home 01</a></li>
                    <li><a href="#">Home 02</a></li>
                    <li><a href="#">Home 03</a></li>
                    <li><a href="#">Home 04</a></li>
                  </ul>
                </li>
                <li>
                  <a class="pages" href="#">Page</a>
                  <ul class="sub-menu">
                    <li><a href="#">About</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Reviews</a></li>
                    <li><a href="#">pricing</a></li>
                    <li><a href="#">FAQ</a></li>
                  </ul>
                </li>
                <li>
                  <a class="pages" href="#">Services</a>
                  <ul class="sub-menu">
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Services 2</a></li>
                    <li><a href="#">Service Details</a></li>
                  </ul>
                </li>
                <li>
                  <a class="pages" href="#">Project</a>
                  <ul class="sub-menu">
                    <li><a href="#">Portfolio</a></li>
                    <li><a href="#">Project details</a></li>
                  </ul>
                </li>
                <li>
                  <a class="pages" href="#">Blog</a>
                  <ul class="sub-menu">
                    <li><a href="#">Blog grid</a></li>
                    <li><a href="#">Blog List</a></li>
                    <li><a href="#">Blog Details</a></li>
                  </ul>
                </li>
                <li><a href="#">contacts</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div> -->
  <!-- mobile-menu-area end -->		
</header>












