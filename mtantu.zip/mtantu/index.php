<!doctype html>
<html class="no-js" lang="en">
  <head>
		<title>mTantu</title>
  	<?php include('top.php'); ?>
  </head>
  <body>
  	<?php include('header.php'); ?>

























    <div class="intro-area intro-area-4 dv_1146270820">
      <div class="bg-wrapper">
        <img src="img/background/bg2.jpg" alt="">
      </div>
      <div class="particules_wrrpr" id="particles-js"></div>
      <div class="intro-content">
        <div class="slider-content">
          <div class="container">
            <div class="row">

              <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="layer-1 wow fadeInUp" data-wow-delay="0.3s">
                  <h5 class="best-title">mTantu</h5>
                  <h2 class="title2">mTantu That Rely On Mission <span class="color-text">Critical Wi-Fi</span> To Conduct Business</h2>
                </div>
                <div class="layer-2 wow fadeInUp" data-wow-delay="0.5s">
                  <p>We aren’t like other providers because we measure Wi-Fi performance from the client’s point of view and provide data that is not tracked by the Wireless LAN vendor.</p>
                </div>
              </div>

              <div class="col-md-6 col-sm-12 col-xs-12 dv_1222270820">
                <img class="img1_1222270820" src="img/home_img1.gif">
                <img class="img2_1222270820" src="img/home_img2.gif">
                <img class="img3_1222270820" src="img/home_img3.gif">
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
























    <div class="about-area about-area-3 area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="overview-text">
              <span class="over-text">Smart Sensor</span>
              <h2>Distributed mTantu Smart Sensors are integrated with NEWS platform</h2>
              <!-- <p>Replacing a  maintains the amount of lines. When replacing a selection. help agencies to define their new business objectives and then create. maintains the amount of lines. When replacing a selection. help agencies to define their new business objectives and then create.</p> -->
              <ul>

								<li><a href="javascript:void(0);">Intelligent-Edge agents with inbuilt machine learning algorithms</a></li>
								<li><a href="javascript:void(0);">Identification of the problems at the source</a></li>
								<li><a href="javascript:void(0);">On-premises advanced sensor hardware</a></li>
								<li><a href="javascript:void(0);">Maximizing network uptime, device connectivity & network ROI</a></li>
								<li><a href="javascript:void(0);">Edge Analytics as the core USP</a></li>
								<li><a href="javascript:void(0);">Next-gen ML and Deep Neural Net/AI algorithms</a></li>
								<li><a href="javascript:void(0);">Best fit solution for distributed organizations</a></li>

              </ul>
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="ab-image">
              <img src="img/img1.png" alt="">
              <!-- <div class="big-content">
                <span class="big-text">12</span>
                <span class="under-text">Cyber security Experience</span>
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>

















    <div class="about-area about-area-3 area-padding text-center bg-color2">
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <h2 class="hd1_0353260820">Sprinkling of mTantu Sensors on Enterprise NW</h2>
          </div>
          <div class="col-xs-12">
            <img src="img/img2.png" alt="">
          </div>
        </div>
      </div>
    </div>
































		<div class="area-padding bg-color customers_slider_wrrpr">
		  <div class="container">
		    <div class="row">
		      <div class="col-md-12 col-sm-12 col-xs-12">
		        <div class="section-headline text-center">
		          <h2>Some of our customers</h2>
		          <!-- <p>Help agencies to define their new business objectives and then create professional software.</p> -->
		        </div>
		      </div>
		    </div>
		    <div class="row">

          <div class="col-md-offset-1 col-md-10 col-sm-12 col-xs-12">
            <div class="award-items award-carousel dv_1235270820">
              <div class="single-award">
                <img src="img/brand/vodafone_idea.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/nokia.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/vodafone_idea.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/nokia.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/vodafone_idea.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/nokia.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/vodafone_idea.jpg" alt="">
              </div>
              <div class="single-award">
                <img src="img/brand/nokia.jpg" alt="">
              </div>
            </div>
          </div>



		    </div>
		  </div>
		</div>










































    <div class="about-area about-area-3 area-padding text-center" style="padding-bottom: 40px;">
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <h2 class="hd1_0353260820">mTantu Products</h2>
          </div>
          <div class="col-xs-6">
            <img src="img/img5.png" alt="">
          </div>
          <div class="col-xs-6">
            <img src="img/img6.png" alt="">
          </div>
        </div>
      </div>
    </div>




















































    <div class="sub-service-area area-padding-2">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline white-headline text-center">
              <h2>Important KPIs for Validation & Troubleshooting </h2>
              <!-- <p>Dummy text is also used to demonstrate the appearance of different typefaces and layouts</p> -->
            </div>
          </div>
        </div>
        <div class="row">
          <div class="sub-service-all">

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">RSSI</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Noise Floor</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">SNR/SINR</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Airtime / Channel Utilization (Duty cycle</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Throughput</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Cipher Suites</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Minimum Basic Rate</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">SSIDs</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Retransmissions (retries)</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Co-Channel Interference (CCI)</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Channel Reuse</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Channels</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Channel Widths</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Packet Loss</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Jitter</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-offset-2 col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">Latency</a></h4>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <div class="single-sub-service">
                <!-- <a class="sub-service-images" href="javascript:void(0);"><i class="flaticon-037-lock"></i></a> -->
                <div class="sub-service-content">
                  <h4><a href="javascript:void(0);">MOS</a></h4>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>


























<!--     <div class="about-area about-area-3 area-padding text-center bg-color2">
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <img src="img/zfcsa.png" alt="">
          </div>
        </div>
      </div>
    </div>
 -->





































    <div class="welcome-area area-padding-2 bg_img1_colors">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>mTantu Productline Offerings </h2>
              <!-- <p>Dummy text is also used to demonstrate the appearance of different typefaces and layouts</p> -->
            </div>
          </div>
        </div>
        <div class="row">
          <div class="well-inner">

            <div class="col-md-4 col-sm-6 col-xs-12 dv1_0459260820">
              <div class="well-services">
                <div class="dv2_0459260820">
                  <img src="img/active-passive-wifi-analytics-sensor.jpg">
                </div>
                <div class="well-content">
                  <h4>Active/Passive WIFI analytics sensor</h4>
                </div>
              </div>
            </div>

            <!-- <div class="col-md-4 col-sm-6 col-xs-12 dv1_0459260820">
              <div class="well-services">
                <div class="dv2_0459260820">
                  <img src="img/soft-sensor-android-ios-windows-linux.jpg">
                </div>
                <div class="well-content">
                  <h4>Soft Sensor (Android, ios, Windows, Linux)</h4>
                </div>
              </div>
            </div> -->

            <div class="col-md-4 col-sm-6 col-xs-12 dv1_0459260820">
              <div class="well-services">
                <div class="dv2_0459260820">
                  <img src="img/edge-analytics-fusion-engine.jpg">
                </div>
                <div class="well-content">
                  <h4>Edge-analytics Fusion engine</h4>
                </div>
              </div>
            </div>


            <div class="col-md-4 col-sm-6 col-xs-12 dv1_0459260820">
              <div class="well-services">
                <div class="dv2_0459260820">
                  <img src="img/saas-application.jpg">
                </div>
                <div class="well-content">
                  <h4>Enterprise Software as a Service (SaaS) application</h4>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </div>








































































  	<?php include('footer.php'); ?>
    <script type="text/javascript" src="js/particules/particles.js"></script>
    <script type="text/javascript" src="js/particules/app.js"></script>

  </body>
</html>