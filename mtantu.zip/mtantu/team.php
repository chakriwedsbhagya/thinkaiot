<!doctype html>
<html class="no-js" lang="en">
  <head>
    <title>Team | mTantu</title>
    <?php include('top.php'); ?>
  </head>
  <body>
    <?php include('header.php'); ?>











    <div class="page-area" style="background-image: url(img/background/bread3.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="breadcrumb text-center">
              <div class="bread-content">
                <div class="section-headline white-headline text-center">
                  <h2>Our Team</h2>
                </div>
                <ul>
                  <li class="home-bread">Home</li>
                  <li>Our Team</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>








    <div class="team-area bg-color-2 area-padding-2">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>mTantu Expert Team</h2>
              <!-- <p>We help agencies to define their new business objectives and then create the road map</p> -->
            </div>
          </div>
        </div>
        <div class="row">
          <div class="team-member text-center">



            <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1110280820">
              <div class="single-member dv_1110280820">
                <div class="team-img">
                  <a href="javascript:void(0);">
                  	<img src="img/team/rajeev-gandhi.jpg" alt="">
                  </a>
                  <ul class="team-hover">
                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#team_pp_rajeev_gandhi">View More</a></li>
                  </ul>
                </div>
                <div class="team-content">
                  <h4>Rajeev Gandhi</h4>
                  <p>CEO & CoFounder</p>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1110280820">
              <div class="single-member dv_1110280820">
                <div class="team-img no_team_data">
                  <a href="javascript:void(0);">
                  	<img src="img/team/gurmeet-likhari.jpg" alt="">
                  </a>
                  <!-- <ul class="team-hover">
                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal">View More</a></li>
                  </ul> -->
                </div>
                <div class="team-content">
                  <h4>Gurmeet Likhari</h4>
                  <p>CFO & CoFounder</p>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1110280820">
              <div class="single-member dv_1110280820">
                <div class="team-img">
                  <a href="javascript:void(0);">
                  	<img src="img/team/venkatesh-raju.jpg" alt="">
                  </a>
                  <ul class="team-hover">
                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#team_pp_venkatesh_raju">View More</a></li>
                  </ul>
                </div>
                <div class="team-content">
                  <h4>CGVenkatesh Raju</h4>
                  <p>CTO & CoFounder</p>
                </div>
              </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12 wrrpr_1110280820">
              <div class="single-member dv_1110280820">
                <div class="team-img">
                  <a href="javascript:void(0);">
                  	<img src="img/team/girl_dummy.jpg" alt="">
                  </a>
                  <ul class="team-hover">
                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#team_pp_swarnalatha">View More</a></li>
                  </ul>
                </div>
                <div class="team-content">
                  <h4>Swarnalatha</h4>
                  <p>Architect</p>
                </div>
              </div>
            </div>



          </div>
        </div>
      </div>
    </div>






























































    <div class="modal fade popup_1110280820" id="team_pp_rajeev_gandhi" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Rajeev Gandhi <span>CEO & CoFounder</span></h4>
          </div>
          <div class="modal-body">
            <p>Rajiv Gandhi, Head of MobileComm India is responsible for all wireless engineering activities in India and South East Asia. He has over 20 years of rich and diverse experience in the telecommunication industry, from GSM to UMTS to LTE. Prior to starting his own venture in 2008 he was involved in RF designs, network optimizations and has led teams on international projects for GSM and WCDMA technologies provided by Motorola and Nokia Siemens Networks. Rajiv has worked on Projects around the globe from India to Japan to Canada to UK. Rajiv was involved with the team that made the First GPRS Call in Asia and also first GPRS call in India. In addition to delivering long-lasting and business-creating partnerships, Rajiv leverages his extensive technical background to bring new capabilities and growth to the company’s learning division. Rajiv is an excellent Manager who very strongly believes in Team Work and he has fantastic communication and Presentation skills. Rajiv is a total GIZMO freak. If he is not busy with Telecom you can find him singing. He has done his Engineering in Electronics and Communications from Regional Engineering College Kurukshetra and then went on to complete MBA in marketing from Symbiosis, Pune.</p>
          </div>
        </div>
      </div>
    </div>


    <div class="modal fade popup_1110280820" id="team_pp_venkatesh_raju" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">CGVenkatesh Raju <span>CTO & CoFounder</span></h4>
          </div>
          <div class="modal-body">
            <p>Technologist with 17+ years of Embedded, Enterprise-Networking(Wired/Wireless-WLAN), IoT, Machine learning, AI products development expertise. Strategic leader with strong business acumen and growth mindset. Well-rounded collaborative executive, with the ability to build trust, influence stakeholders, and motivate teams to deliver high impact results. Responsible for the key Ideas generation and translation of those ideas/concept into product reality and generate revenues for the company, roll-out Proof of concepts(Minimal Viable Product). Conduct technical product workshops and create "WoW" factor among the clients and pitch in for product expansions. As a system architect shipped embedded and defense-networking communications flagship products. Development of software complaint to the standards like RFC, ETSI, ITU, IEEE.Penchant towards doing AI and Machine Learning Research and Research oriented Products.Self-used to research & develop and would dedicate energies during spare-time towards developing POC prototypes . Passionate towards experimenting, building and innovating things.</p>
          </div>
        </div>
      </div>
    </div>


    <div class="modal fade popup_1110280820" id="team_pp_swarnalatha" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Swarnalatha <span>Architect</span></h4>
          </div>
          <div class="modal-body">
            <p>Telecommunication and Embedded software professional with 12+ years of work experience in real time software Design, Protocol Stack Development, Customization of protocol stacks for Telecom/Embedded system software for Wireless Access Networks.</p>
          </div>
        </div>
      </div>
    </div>







    <?php include('footer.php'); ?>
  </body>
</html>